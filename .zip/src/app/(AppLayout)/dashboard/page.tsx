import React from 'react';

const Dashboard = () => {
    return (
        <div className='mt-7'>
            <h1>Dashboard</h1>
        </div>
    );
};

export default Dashboard;