import Hero from '@/container/about/components/sections/Hero';
import React from 'react';

const page = () => {
    return (
        <div>
            about page
            <Hero />
        </div>
    );
};

export default page;