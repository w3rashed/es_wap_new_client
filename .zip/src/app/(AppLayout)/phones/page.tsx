import React from 'react';

const Phones = () => {
    return (
        <div>
            <h1>Phones</h1>
        </div>
    );
};

export default Phones;