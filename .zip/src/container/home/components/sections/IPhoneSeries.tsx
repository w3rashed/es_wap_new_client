import React from 'react';
import SectionContainer from '@/components/shared/SectionContainer';

const IPhoneSeries = () => {
    return (
        
            <div>
                <h3 className='text-[30px] leading-[1.2] font-bold text-gray-900'>iPhone 16 Series</h3>
            </div>
        
    );
};

export default IPhoneSeries;