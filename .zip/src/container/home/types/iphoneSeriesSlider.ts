export type TProductQuery = {
    id: string;
    name: string;
    storage: string;
    price: string;
    originalPrice: string;
    rating: string;
}


