export type TUser={
    id: number;
    name: string;
    email: string;
}