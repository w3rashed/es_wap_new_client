import { TUser } from "../type/user";

export const users:TUser[] = [
    { id: 1, name: "Rahim", email: "rahim@example.com" },
    { id: 2, name: "Karim", email: "karim@example.com" },
    { id: 3, name: "Fatema", email: "fatema@example.com" },
    { id: 4, name: "Jamil", email: "jamil@example.com" },
    { id: 5, name: "Nusrat", email: "nusrat@example.com" }
  ];
  